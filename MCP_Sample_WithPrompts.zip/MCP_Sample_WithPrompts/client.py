#!/usr/bin/env python3
"""
Interactive MCP Client Example with Proper Review Code Handling.
"""

import asyncio
import logging
import json
import urllib.parse
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.types import TextContent, TextResourceContents

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def run_calculator(session):
    try:
        a = int(input("Enter first number (a): "))
        b = int(input("Enter second number (b): "))
        result = await session.call_tool("add", arguments={"a": a, "b": b})
        if result and result.content:
            text = next((c for c in result.content if isinstance(c, TextContent)), None)
            if text:
                print(f"✅ Result: {a} + {b} = {text.text}")
    except Exception as e:
        print(f"❌ Calculator error: {e}")

async def run_completion(session):
    prompt = input("Enter your prompt: ")
    result = await session.call_tool("completion", arguments={
        "model": "gpt-4",
        "prompt": prompt,
        "temperature": 0.7
    })
    if result and result.content:
        text = next((c for c in result.content if isinstance(c, TextContent)), None)
        if text:
            print(f"\n🧠 Completion:\n{text.text}")

async def run_model_list(session):
    result = await session.read_resource("models://")
    if result and result.contents:
        text = next((c for c in result.contents if isinstance(c, TextResourceContents)), None)
        if text:
            models = json.loads(text.text)
            print("\n🧩 Available Models:")
            for model in models.get("models", []):
                print(f" - {model['name']} ({model['id']}): {model['description']}")

async def run_greeting(session):
    name = input("Enter your name for a greeting: ")
    encoded_name = urllib.parse.quote(name)
    result = await session.read_resource(f"greeting://{encoded_name}")
    if result and result.contents:
        text = next((c for c in result.contents if isinstance(c, TextResourceContents)), None)
        if text:
            print(f"👋 Greeting: {text.text}")

async def run_code_review(session):
    print("🔍 Paste your Python code (end input with a single blank line):")
    lines = []
    while True:
        line = input()
        if line.strip() == "":
            break
        lines.append(line)
    code = "\n".join(lines)

    try:
        result = await session.get_prompt("review_code", {"code": code})
        if result and result.messages:
            message = next((m for m in result.messages if m.content), None)
            if message and message.content:
                text = next((c for c in [message.content] if isinstance(c, TextContent)), None)
                if text:
                    print("\n🛠️ Code Review Feedback:")
                    print(text.text)
        else:
            print("⚠️ No feedback received.")
    except Exception as e:
        print(f"❌ Error during code review: {e}")

async def main():
    print("🔌 Starting Interactive MCP Client...\n")

    server_params = StdioServerParameters(
        command="python",
        args=["server.py"],  # Adjust this if your server filename differs
    )

    try:
        async with stdio_client(server_params) as (reader, writer):
            async with ClientSession(reader, writer) as session:
                await session.initialize()

                while True:
                    print("\n🎛️ MCP Client Menu")
                    print("1. Use Calculator Tool")
                    print("2. Use Completion Tool")
                    print("3. List Available Models")
                    print("4. Get a Greeting")
                    print("5. Code preview")
                    print("0. Exit")
                    
                    choice = input("Select an option: ").strip()
                    if choice == "1":
                        await run_calculator(session)
                    elif choice == "2":
                        await run_completion(session)
                    elif choice == "3":
                        await run_model_list(session)
                    elif choice == "4":
                        await run_greeting(session)
                    elif choice == "5":
                        await run_code_review(session)
                    elif choice == "0":
                        print("👋 Exiting MCP client.")
                        break
                    else:
                        print("❌ Invalid option. Try again.")

    except Exception:
        logger.exception("An error occurred")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())
